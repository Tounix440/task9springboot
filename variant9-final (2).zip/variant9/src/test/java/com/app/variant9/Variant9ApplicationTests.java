package com.app.variant9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Variant9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
