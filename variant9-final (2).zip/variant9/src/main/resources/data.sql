INSERT INTO author (group_number, exam_date, name, surname, task_variant)
VALUES (62488, '2022-06-06', 'Edgar', 'Gauvrit', 9);

INSERT INTO book (id, name, author, pages, price)
VALUES (1, 'Don Quixote', 'Miguel de Cervantes', 310, 20.10);

INSERT INTO book (id, name, author, pages, price)
VALUES (2, 'War and Peace', 'Leo Tolstoy', 1340, 70.40);

INSERT INTO book (id, name, author, pages, price)
VALUES (3, 'Hamlet', 'William Shakespeare', 75, 14.20);

INSERT INTO book (id, name, author, pages, price)
VALUES (4, 'The Odyssey', 'Homer', 67, 12.70);