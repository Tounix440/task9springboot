package com.app.variant9.service;

import com.app.variant9.model.Author;
import com.app.variant9.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthorService {
    @Autowired
    AuthorRepository authorRepository;

    public Author getInfo() {
        Optional<Author> author = authorRepository.findById(62488);
        return author.orElse(null);
    }
}
