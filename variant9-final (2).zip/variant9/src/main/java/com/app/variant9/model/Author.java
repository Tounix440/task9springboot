package com.app.variant9.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer groupNumber;
    private String name;
    private String surname;
    private int taskVariant;
    private LocalDate examDate;

    public Author() {
    }

    public Author(Integer groupNumber, String name, String surname, int taskVariant, LocalDate examDate) {
        this.groupNumber = groupNumber;
        this.name = name;
        this.surname = surname;
        this.taskVariant = taskVariant;
        this.examDate = examDate;
    }

    public Integer getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(Integer groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getTaskVariant() {
        return taskVariant;
    }

    public void setTaskVariant(int taskVariant) {
        this.taskVariant = taskVariant;
    }

    public LocalDate getExamDate() {
        return examDate;
    }

    public void setExamDate(LocalDate examDate) {
        this.examDate = examDate;
    }
}
