package com.app.variant9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Variant9Application {

	public static void main(String[] args) {
		SpringApplication.run(Variant9Application.class, args);
	}

}
