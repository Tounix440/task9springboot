package com.app.variant9.repository;

import com.app.variant9.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

    @Query(
            value = "SELECT SUM(price) FROM book;",
            nativeQuery = true)
    Double getTotalPrice();
}
