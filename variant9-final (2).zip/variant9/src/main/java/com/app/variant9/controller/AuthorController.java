package com.app.variant9.controller;

import com.app.variant9.model.Author;
import com.app.variant9.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthorController {
    @Autowired
    AuthorService authorService;

    @GetMapping("/info")
    public Author getInfo() {
        return authorService.getInfo();
    }
}
